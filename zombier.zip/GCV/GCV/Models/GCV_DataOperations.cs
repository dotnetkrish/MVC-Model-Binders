﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GCV.Models
{
    public class GCV_DataOperations
    {
        GlobalCustomerView customer = new GlobalCustomerView();
        #region search    
        public void search();
        #endregion
        #region update
        public void updateAcct(GlobalCustomerView updateFields,List<string> AcctNumber)
        {
            foreach (string str in AcctNumber)
            {
                customer=findCustomer(str);
               
                customer.Creditlimit = updateFields.Creditlimit;
                customer.RiskScore = updateFields.RiskScore;
                customer.CustomerServiceModelLevel = updateFields.CustomerServiceModelLevel;
                customer.CreditStatus = updateFields.CreditStatus;
                
                customer.VZAccountManagerContact = updateFields.VZAccountManagerContact;
                customer.VZAccountsPayableContact = updateFields.VZAccountsPayableContact;
                customer.VZClaimsMgrSupervisor = updateFields.VZClaimsMgrSupervisor;
                customer.VZSalesServiceTeamContact = updateFields.VZSalesServiceTeamContact;

                customer.WholesaleID = updateFields.WholesaleID;
                customer.InternationalEnterprise = updateFields.InternationalEnterprise;
                customer.CorporateBillingandCollections = updateFields.CorporateBillingandCollections;

            }
        }
       private GlobalCustomerView findCustomer(string acctNum)
        {
            return customer;
        }
        #endregion

    }
}

/*
 Customer Service Model Level (CSM Level)
Credit limit
Risk Score
Credit Hold / Active Embargo Status / Bankruptcy
VZ Claims Mgr, Supervisor etc. - all applicable areas of business
VZ Sales/Service Team Contact - all applicable areas of business
VZ Account Manager Contact - all applicable areas of business
VZ Accounts Payable Contact - all applicable areas of business
Wholesale ID (WID)
International Enterprise
Corporate Billing and Collections
*/